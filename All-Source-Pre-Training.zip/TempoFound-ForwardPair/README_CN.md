# TempoFound + Forward-Pair 统一代码包

本项目按照论文当前主线把两个原仓库整理为一个可运行工程：先用
Forward-Pair 在目标域训练期内部筛选源域，再用 TempoFound 对所选源域
进行跨数据集时序图预训练，最后在目标域完成冻结编码器迁移评测。

## 关键保证

- 默认主流程只运行论文中的 Forward-Pair，不再误跑旧版 `proposed` 或
  leave-one 选择器。
- K=4 与 K=6 共用一份源码，只切换 YAML 配置。
- 代理阶段只读取目标训练期；训练期按时间顺序切成前 80% 校准和后 20%
  探测，目标验证集和测试集不参与选源。
- 每个 epoch 的源域总更新次数严格不超过 160，源域较小时会将剩余预算
  重新分配给其他源域。
- 新实验默认使用论文中的归一化 `paper_sincos` 时间编码；没有版本元数据
  的旧 TempoFound checkpoint 自动按 `legacy_cos` 加载。
- 旧版只有 4 个自适应任务权重时会确定性迁移：原值不变，新增 NPP 权重置零。
- Forward-Pair 必须得到 K 个单源和 K-1 个锚点配对，共 `2K-1` 个有效候选；
  缺失、重复、NaN、目标/种子不一致或配置摘要过期都会立即报错。

## 安装与自检

```bash
cd TempoFound-ForwardPair
python -m pip install -e '.[test]'
python -m pytest -q
bash experiments/run_smoke.sh
```

冒烟测试使用自动生成的微型数据，只验证代码链路，不能写入论文。

## 正式 K=4 实验

```bash
nohup env \
  PROCESSED_DIR=/root/autodl-tmp/temp/processed \
  OUTPUT_ROOT=/root/autodl-tmp/temp/server_runs/tempofound_forward_pair_k4 \
  DEVICE=cuda:0 \
  bash experiments/run_k4_primary.sh \
  > /root/autodl-tmp/temp/k4.log 2>&1 &
```

默认目标为 MOOC、Wikipedia、Reddit，随机种子为 0、1、2、3、42。对每个
目标，配置自动从五数据集池中排除目标，得到四个候选源域。

## K=6 扩展实验

```bash
nohup env \
  PROCESSED_DIR=/root/autodl-tmp/temp/processed \
  OUTPUT_ROOT=/root/autodl-tmp/temp/server_runs/tempofound_forward_pair_k6 \
  DEVICE=cuda:0 \
  bash experiments/run_k6_scalability.sh \
  > /root/autodl-tmp/temp/k6.log 2>&1 &
```

七数据集池为 Wikipedia、Reddit、MOOC、UCI、Enron、LastFM、SocialEvo。
MOOC 使用 0、1、42 三个种子；Wikipedia 与 Reddit 使用 seed 42 诊断。

## 输出结构

每个 `target/seed*` 目录包含：

- `candidates/`：单源和锚点配对的 checkpoint 与训练期代理分数；
- `selection/selection.json`：锚点、最佳配对、增益、阈值和最终源集合；
- `final/forward_pair/` 与 `final/all_sources/`：同预算最终预训练模型；
- `transfer/`：冻结编码器迁移结果；
- `summary.json`：Forward-Pair 与全源 AP 对照。

服务器验收步骤见 `docs/SERVER_ACCEPTANCE_CN.md`，论文模块和文件的逐项
对应见 `docs/PAPER_CODE_MAPPING.md`。
