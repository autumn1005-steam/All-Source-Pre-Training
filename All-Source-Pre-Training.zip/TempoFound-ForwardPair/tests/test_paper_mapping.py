import importlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_every_manuscript_component_resolves_to_a_real_symbol() -> None:
    mapping = json.loads(
        (ROOT / "docs/PAPER_CODE_MAPPING.json").read_text(encoding="utf-8")
    )
    expected = {
        "dataset_adapters",
        "causal_temporal_encoder",
        "paper_time_encoding",
        "mtlp_tnp_cdc_edc_npp",
        "adaptive_weighting",
        "target_training_proxy",
        "forward_pair",
        "global_batch_budget",
        "frozen_transfer",
        "graphmixer_control",
    }

    assert set(mapping) == expected
    for component, target in mapping.items():
        module = importlib.import_module(target["module"])
        assert hasattr(module, target["symbol"]), component
        assert target["manuscript_section"]
