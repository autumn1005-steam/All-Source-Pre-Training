# Verification record

Verified on 2026-09-03 at implementation commit
`4ace865315a1b571738977bc65f59b1dedc329a2`.

Environment:

- Python 3.12.13
- PyTorch 2.12.0+cpu

Commands and observed results:

```text
python -m pytest -q
52 passed in 15.70s

python -m compileall -q src scripts tests
exit 0

find experiments -name '*.sh' -print0 | xargs -0 -n1 bash -n
exit 0

python scripts/check_package.py
Package boundary check passed: source, configs, tests, and docs only.

bash experiments/run_smoke.sh
Smoke test passed; candidate_count=7; exit 0.

git diff --check 31723aa..HEAD
exit 0
```

The smoke run uses generated toy data and is only an integration check. It is
not a reproduction of the manuscript's reported metrics.
