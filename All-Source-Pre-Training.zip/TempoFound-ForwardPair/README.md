# TempoFound + Forward-Pair

This repository is the unified implementation for the manuscript on
target-conditioned source composition in cross-dataset temporal graph
pre-training. Forward-Pair screens source domains using only the target's
chronological training interval; TempoFound then pre-trains a shared temporal
encoder on the selected source set and transfers it to the held-out target.

## What is unified

- one TempoFound model for K=4 and K=6 experiments;
- dataset-specific node/edge adapters and a shared causal TGAT backbone;
- MTLP, TNP, CDC, EDC, and NPP with learned uncertainty weighting;
- exact global per-epoch update budgets across source sets;
- deterministic Forward-Pair selection with exactly `2K-1` candidates;
- frozen, full, and scratch transfer protocols;
- a GraphMixer-style backbone and Random-7/exhaustive/greedy controls;
- paper `paper_sincos` and released-checkpoint `legacy_cos` time modes.

New training defaults to the normalized paired sine/cosine encoding described
in the manuscript. Released TempoFound checkpoint payloads without format
metadata are loaded as `legacy_cos`; the TGAT parameter names and shapes are
kept compatible.
Legacy payloads with four adaptive task weights are migrated deterministically:
the four stored values are preserved and the added NPP weight starts at zero.

## Install

```bash
python -m pip install -e '.[test]'
```

Processed data use the original layout:

```text
processed/
├── ml_mooc.csv
├── ml_mooc.npy
└── ml_mooc_node.npy
```

The CSV requires `u`, `i`, `idx`, and `ts` columns. Row zero in feature arrays
is reserved for padding.

## Verify locally

```bash
python -m pytest -q
bash experiments/run_smoke.sh
python scripts/check_package.py
```

The smoke command creates deterministic temporary graphs and exercises all
seven K=4 candidates, final selected/all-source pre-training, and frozen
transfer on CPU. Its metrics are engineering checks, not manuscript results.

## Run manuscript protocols

```bash
PROCESSED_DIR=/path/to/processed \
OUTPUT_ROOT=/path/to/runs/k4 \
DEVICE=cuda:0 \
bash experiments/run_k4_primary.sh

PROCESSED_DIR=/path/to/processed \
OUTPUT_ROOT=/path/to/runs/k6 \
DEVICE=cuda:0 \
bash experiments/run_k6_scalability.sh
```

The pipeline resumes only artifacts whose target, seed, source set, and full
configuration digest match. Stale outputs are recomputed. Selection artifacts
record all proxy scores, the anchor, pair gain, margin, source commits, and the
target-training-only information boundary.

See `README_CN.md`, `docs/PAPER_CODE_MAPPING.md`, and
`docs/SERVER_ACCEPTANCE_CN.md` for the full handoff.
