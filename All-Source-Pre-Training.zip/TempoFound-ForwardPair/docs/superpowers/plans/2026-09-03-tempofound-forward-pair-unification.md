# TempoFound + Forward-Pair Unification Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build one paper-aligned repository that runs Forward-Pair source screening, TempoFound pre-training, and target transfer while supporting both manuscript and legacy time encodings.

**Architecture:** Package the representation engine under `src/tempofound` and the selector under `src/forward_pair`. Python CLIs expose pre-training, target-train proxy scoring, selection, and transfer; thin shell orchestrators bind them into K=4, K=6, smoke, and control protocols. One harmonic encoder uses checkpoint metadata to select `paper_sincos` or `legacy_cos` without duplicate model implementations.

**Tech Stack:** Python 3.10+, PyTorch 2.0+, NumPy, pandas, scikit-learn, SciPy, pytest, Bash

**Spec:** `docs/superpowers/specs/2026-09-03-tempofound-forward-pair-unification-design.md`

## Global Constraints

- New runs default to `paper_sincos`; checkpoints without format metadata load as `legacy_cos`.
- Forward-Pair is the default source selector and must evaluate exactly `2K-1` candidates.
- Selector calibration and probe scoring use only the chronological target-training interval.
- Default margin is `0.002`; calibration fraction is `0.8`.
- Primary pre-training defaults are hidden dimension 128, time dimension 64, two layers, two heads, ten neighbors, dropout 0.1, 25 epochs, batch size 512, and 160 total batches per epoch.
- K=4 and K=6 are configuration presets over one implementation, never duplicate source trees.
- Generated data, checkpoints, logs, results, environments, and source archives are excluded from the deliverable.
- Preserve provenance for TempoFound `560ca56e8b4ecdb63ad9ba82d1c16cf7c5e9a723` and Forward-Pair `75357f19a0bb8f31aa8873b750d638181d0aec8a`.

## File Map

- `src/tempofound/config.py`: typed YAML configuration and validation.
- `src/tempofound/data.py`: processed-dataset loading, chronological splits, and causal neighbor finders.
- `src/tempofound/graph.py`: strict historical-neighbor indexing.
- `src/tempofound/layers.py`: attention, merge, and harmonic time layers.
- `src/tempofound/model.py`: adapters, shared encoder, five heads, losses, and transfer heads.
- `src/tempofound/budget.py`: exact global update-budget allocation.
- `src/tempofound/checkpoint.py`: versioned save/load and time-mode resolution.
- `src/tempofound/pretrain.py`: compute-matched multi-source training.
- `src/tempofound/transfer.py`: frozen-encoder, full, and scratch target evaluation.
- `src/forward_pair/proxy.py`: target-training calibration/probe scoring.
- `src/forward_pair/selector.py`: deterministic singleton/anchor-pair selection.
- `src/forward_pair/artifacts.py`: metadata-rich score and selection artifacts.
- `src/forward_pair/pipeline.py`: resumable stage orchestration and artifact validation.
- `scripts/*.py`: stable command-line entry points.
- `experiments/*.sh`: K=4, K=6, smoke, and optional control launchers.
- `configs/*.yaml`: protocol presets.
- `tests/`: formula, contract, leakage, CLI, and package tests.

---

### Task 1: Package Scaffold and Provenance

**Files:**
- Create: `pyproject.toml`
- Create: `src/tempofound/__init__.py`
- Create: `src/forward_pair/__init__.py`
- Create: `PROVENANCE.json`
- Create: `.gitignore`
- Test: `tests/test_package_contract.py`

**Interfaces:**
- Consumes: none.
- Produces: importable `tempofound` and `forward_pair` packages and machine-readable provenance.

- [ ] **Step 1: Write the failing package-contract test**

```python
import json
from pathlib import Path

def test_packages_and_provenance_are_present():
    import tempofound
    import forward_pair
    provenance = json.loads(Path("PROVENANCE.json").read_text())
    assert tempofound.__version__ == "1.0.0"
    assert forward_pair.__version__ == "1.0.0"
    assert provenance["tempofound_commit"] == "560ca56e8b4ecdb63ad9ba82d1c16cf7c5e9a723"
    assert provenance["forward_pair_commit"] == "75357f19a0bb8f31aa8873b750d638181d0aec8a"
```

- [ ] **Step 2: Run the test and verify import failure**

Run: `python -m pytest tests/test_package_contract.py -v`

Expected: FAIL because the packages do not exist.

- [ ] **Step 3: Add the package metadata and provenance**

```toml
[build-system]
requires = ["setuptools>=68"]
build-backend = "setuptools.build_meta"

[project]
name = "tempofound-forward-pair"
version = "1.0.0"
requires-python = ">=3.10"
dependencies = ["numpy>=1.24", "pandas>=2.0", "scikit-learn>=1.3", "scipy>=1.10", "torch>=2.0", "PyYAML>=6.0"]

[tool.setuptools.packages.find]
where = ["src"]
```

Both package initializers define `__version__ = "1.0.0"`. `PROVENANCE.json` stores the two source URLs, exact commits, and manuscript filename. `.gitignore` excludes `processed/`, `saved_models/`, `saved_checkpoints/`, `results/`, `server_runs/`, `logs/`, `.venv/`, caches, and model/data suffixes.

- [ ] **Step 4: Install editable and rerun the contract test**

Run: `python -m pip install -e . --no-deps && python -m pytest tests/test_package_contract.py -v`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add pyproject.toml src PROVENANCE.json .gitignore tests/test_package_contract.py
git commit -m "build: scaffold unified TempoFound Forward-Pair package"
```

### Task 2: Configuration, Data Boundaries, and Historical Neighbors

**Files:**
- Create: `src/tempofound/config.py`
- Create: `src/tempofound/data.py`
- Create: `src/tempofound/graph.py`
- Create: `configs/k4_primary.yaml`
- Create: `configs/k6_scalability.yaml`
- Create: `configs/smoke.yaml`
- Test: `tests/test_config_and_data.py`
- Test: `tests/test_causal_neighbors.py`

**Interfaces:**
- Consumes: YAML files and processed `ml_<dataset>.csv/.npy/_node.npy` files.
- Produces: `ExperimentConfig.from_yaml(path)`, `split_target_train_period(data, fraction)`, and `NeighborFinder.get_temporal_neighbor(nodes, times, num_neighbors)`.

- [ ] **Step 1: Write failing validation and chronology tests**

```python
def test_target_is_rejected_from_source_pool():
    with pytest.raises(ValueError, match="target.*source"):
        ExperimentConfig(target="mooc", sources=("mooc", "reddit"))

def test_training_period_split_is_stable_and_chronological():
    data = {"train_ts": np.array([4., 1., 3., 2.]), "train_src": np.arange(4), "train_dst": np.arange(4)}
    calibration, probe = split_target_train_period(data, 0.5)
    assert calibration["train_ts"].tolist() == [1., 2.]
    assert probe["train_ts"].tolist() == [3., 4.]
    assert calibration["train_ts"].max() <= probe["train_ts"].min()

def test_equal_timestamp_is_not_historical():
    finder = NeighborFinder.from_events(np.array([1, 1]), np.array([2, 3]), np.array([1, 2]), np.array([5., 6.]))
    nodes, _, times = finder.get_temporal_neighbor(np.array([1]), np.array([6.]), 3)
    assert times[times > 0].tolist() == [5.]
    assert 3 not in nodes.tolist()
```

- [ ] **Step 2: Run tests and verify missing symbols**

Run: `python -m pytest tests/test_config_and_data.py tests/test_causal_neighbors.py -v`

Expected: FAIL on missing modules.

- [ ] **Step 3: Implement exact validation and chronological helpers**

```python
@dataclass(frozen=True)
class ExperimentConfig:
    target: str
    sources: tuple[str, ...]
    calibration_fraction: float = 0.8
    margin: float = 0.002
    time_encoding_mode: str = "paper_sincos"

    def __post_init__(self):
        if self.target in self.sources:
            raise ValueError("target cannot appear in source pool")
        if len(self.sources) < 2 or len(set(self.sources)) != len(self.sources):
            raise ValueError("source pool requires at least two unique datasets")
        if not 0.0 < self.calibration_fraction < 1.0:
            raise ValueError("calibration_fraction must be between zero and one")
```

`NeighborFinder.find_before` uses `np.searchsorted(timestamps, query_time, side="left")` so equal timestamps are excluded. `load_processed_dataset` creates the full causal index but returns explicit chronological train/validation/test arrays using 0.70 and 0.85 quantiles.

- [ ] **Step 4: Add all three YAML presets and rerun tests**

Run: `python -m pytest tests/test_config_and_data.py tests/test_causal_neighbors.py -v`

Expected: PASS for K=4, K=6, smoke parsing, chronology, and strict history.

- [ ] **Step 5: Commit**

```bash
git add src/tempofound/config.py src/tempofound/data.py src/tempofound/graph.py configs tests/test_config_and_data.py tests/test_causal_neighbors.py
git commit -m "feat: add validated protocols and causal temporal data"
```

### Task 3: Dual Harmonic Encoder and Versioned Checkpoints

**Files:**
- Create: `src/tempofound/layers.py`
- Create: `src/tempofound/checkpoint.py`
- Test: `tests/test_time_encoding.py`
- Test: `tests/test_checkpoint_modes.py`

**Interfaces:**
- Consumes: `HarmonicTimeEncoder(time_dim, mode)` and checkpoint dictionaries.
- Produces: `resolve_checkpoint_time_mode(payload, requested=None) -> str`, `build_checkpoint(model, metadata) -> dict`, and shape-compatible dual encoding.

- [ ] **Step 1: Write failing formula and compatibility tests**

```python
def test_paper_sincos_formula():
    encoder = HarmonicTimeEncoder(4, "paper_sincos")
    encoder.basis_freq.data.copy_(torch.tensor([1., 2., 7., 8.]))
    value = encoder(torch.tensor([[0.5]]))
    expected = 0.5 * torch.tensor([[[math.cos(0.5), math.cos(1.0), math.sin(0.5), math.sin(1.0)]]])
    assert torch.allclose(value, expected)

def test_legacy_mode_uses_all_cosine_channels():
    encoder = HarmonicTimeEncoder(4, "legacy_cos")
    encoder.basis_freq.data.copy_(torch.tensor([1., 2., 3., 4.]))
    assert torch.allclose(encoder(torch.zeros(1, 1)), torch.ones(1, 1, 4))

def test_missing_checkpoint_metadata_means_legacy():
    assert resolve_checkpoint_time_mode({"model_state_dict": {}}) == "legacy_cos"
```

- [ ] **Step 2: Run tests and verify missing implementations**

Run: `python -m pytest tests/test_time_encoding.py tests/test_checkpoint_modes.py -v`

Expected: FAIL.

- [ ] **Step 3: Implement one shape-compatible encoder and mode resolver**

```python
class HarmonicTimeEncoder(nn.Module):
    def __init__(self, time_dim: int, mode: str = "paper_sincos"):
        super().__init__()
        if mode == "paper_sincos" and time_dim % 2:
            raise ValueError("paper_sincos requires an even time_dim")
        if mode not in {"paper_sincos", "legacy_cos"}:
            raise ValueError(f"unsupported time encoding mode: {mode}")
        self.time_dim, self.mode = time_dim, mode
        self.basis_freq = nn.Parameter(torch.from_numpy(1 / 10 ** np.linspace(0, 9, time_dim)).float())
        self.phase = nn.Parameter(torch.zeros(time_dim))

    def forward(self, timestamps):
        values = timestamps.unsqueeze(-1)
        if self.mode == "legacy_cos":
            return torch.cos(values * self.basis_freq + self.phase)
        half = self.time_dim // 2
        angles = values * self.basis_freq[:half] + self.phase[:half]
        return torch.cat((torch.cos(angles), torch.sin(angles)), dim=-1) / math.sqrt(self.time_dim)
```

New payloads store `format_version=2` and `time_encoding_mode`. The resolver treats missing fields as legacy and raises on an explicit metadata/request conflict.

- [ ] **Step 4: Run formula and checkpoint tests**

Run: `python -m pytest tests/test_time_encoding.py tests/test_checkpoint_modes.py -v`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/tempofound/layers.py src/tempofound/checkpoint.py tests/test_time_encoding.py tests/test_checkpoint_modes.py
git commit -m "feat: support paper and legacy harmonic time encoding"
```

### Task 4: TempoFound Model, Five Objectives, and Global Budget

**Files:**
- Create: `src/tempofound/model.py`
- Create: `src/tempofound/budget.py`
- Test: `tests/test_model_objectives.py`
- Test: `tests/test_budget.py`

**Interfaces:**
- Consumes: `DatasetSpec`, `NeighborFinder`, adapted raw features, and batch dictionaries.
- Produces: `TemporalGraphFoundationModel.pretrain_forward(...) -> dict[str, Tensor]`, `weighted_pretrain_loss(losses) -> Tensor`, and `allocate_batch_budget(capacities, total_budget) -> dict[str, int]`.

- [ ] **Step 1: Write failing objective and K=6 budget tests**

```python
def test_edc_matches_manuscript_formula():
    forward = torch.tensor([0.0, 1.5, -0.5])
    reverse = torch.tensor([0.0, -0.25, 0.75])
    expected = torch.mean((torch.sigmoid(forward) - torch.sigmoid(reverse)) ** 2)
    assert torch.allclose(edge_direction_consistency_loss(forward, reverse), expected)

def test_model_returns_exactly_five_pretext_losses(synthetic_model_and_batch):
    model, finder, batch = synthetic_model_and_batch
    losses = model.pretrain_forward("source_a", finder, batch)
    assert set(losses) == {"mtlp", "tnp", "cdc", "edc", "npp"}

def test_k6_budget_is_exact():
    result = allocate_batch_budget({f"s{i}": 100 for i in range(6)}, 160)
    assert sum(result.values()) == 160
    assert sorted(result.values()) == [26, 26, 27, 27, 27, 27]
```

- [ ] **Step 2: Run tests and verify failure**

Run: `python -m pytest tests/test_model_objectives.py tests/test_budget.py -v`

Expected: FAIL.

- [ ] **Step 3: Port and adapt the corrected TempoFound engine**

Port adapters, shared recursive temporal attention, link/neighborhood/domain/node-property heads, transfer heads, and five learned `task_log_vars` from the source repositories. Replace the old `TimeEncode` with `HarmonicTimeEncoder`. Name the fourth loss `edc` everywhere and compute:

```python
def weighted_pretrain_loss(self, losses):
    ordered = [losses[name] for name in ("mtlp", "tnp", "cdc", "edc", "npp")]
    return sum(torch.exp(-alpha) * loss + alpha for alpha, loss in zip(self.task_log_vars, ordered))
```

Implement deterministic round-robin budget allocation that redistributes unused capacity and never exceeds `total_budget`.

- [ ] **Step 4: Run model and budget tests**

Run: `python -m pytest tests/test_model_objectives.py tests/test_budget.py -v`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/tempofound/model.py src/tempofound/budget.py tests/test_model_objectives.py tests/test_budget.py
git commit -m "feat: unify TempoFound model and five-task pretraining"
```

### Task 5: Forward-Pair Selector and Auditable Artifacts

**Files:**
- Create: `src/forward_pair/selector.py`
- Create: `src/forward_pair/artifacts.py`
- Test: `tests/test_forward_pair_selector.py`
- Test: `tests/test_artifact_validation.py`

**Interfaces:**
- Consumes: `CandidateScore(config, sources, proxy_ap, seed, target, digest)` records.
- Produces: `select_forward_pair(scores, source_pool, margin) -> SelectionResult` and validated JSON/CSV artifacts.

- [ ] **Step 1: Write failing selection-contract tests**

```python
def test_selector_uses_k_singletons_and_k_minus_one_anchor_pairs():
    scores = candidate_scores_for_anchor_b()
    result = select_forward_pair(scores, ("a", "b", "c", "d"), margin=0.002)
    assert result.anchor == "b"
    assert result.selected_sources == ("b", "d")
    assert result.candidate_count == 7

def test_pair_below_margin_keeps_singleton():
    scores = candidate_scores(pair_gain=0.0019)
    assert select_forward_pair(scores, ("a", "b"), 0.002).selected_sources == ("a",)

def test_stale_digest_is_rejected():
    with pytest.raises(ValueError, match="digest"):
        validate_candidate_scores(mixed_digest_scores())
```

- [ ] **Step 2: Run tests and verify failure**

Run: `python -m pytest tests/test_forward_pair_selector.py tests/test_artifact_validation.py -v`

Expected: FAIL.

- [ ] **Step 3: Implement deterministic two-stage selection**

```python
anchor = min(source_pool, key=lambda source: (-singleton[source].proxy_ap, source))
partner = min((s for s in source_pool if s != anchor), key=lambda source: (-pairs[canonical_pair(anchor, source)].proxy_ap, source))
gain = pairs[canonical_pair(anchor, partner)].proxy_ap - singleton[anchor].proxy_ap
selected = (anchor, partner) if gain + 1e-12 >= margin else (anchor,)
```

Reject missing, extra, duplicate, non-finite, wrong-seed, wrong-target, and mixed-digest scores. Serialize candidate scores, anchor, pair scores, gain, margin, selected set, exact candidate count, information boundary, source commits, and configuration digest.

- [ ] **Step 4: Run selector and artifact tests**

Run: `python -m pytest tests/test_forward_pair_selector.py tests/test_artifact_validation.py -v`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/forward_pair/selector.py src/forward_pair/artifacts.py tests/test_forward_pair_selector.py tests/test_artifact_validation.py
git commit -m "feat: add auditable linear-budget Forward-Pair selector"
```

### Task 6: Training-Only Proxy, Pre-Training, and Transfer CLIs

**Files:**
- Create: `src/forward_pair/proxy.py`
- Create: `src/tempofound/pretrain.py`
- Create: `src/tempofound/transfer.py`
- Create: `scripts/pretrain.py`
- Create: `scripts/score_proxy.py`
- Create: `scripts/select_forward_pair.py`
- Create: `scripts/transfer.py`
- Test: `tests/test_proxy_boundary.py`
- Test: `tests/test_cli_contracts.py`

**Interfaces:**
- Consumes: validated config, processed data, versioned checkpoints, and candidate score paths.
- Produces: pre-trained checkpoints, target-training-only proxy AP/AUC, selection artifacts, and downstream AP/AUC rows.

- [ ] **Step 1: Write failing information-boundary and CLI tests**

```python
def test_proxy_never_receives_validation_or_test_arrays(monkeypatch, target_data):
    calibration, probe = build_proxy_partitions(target_data, 0.8)
    assert set(calibration) == {"train_src", "train_dst", "train_ts", "neighbor_finder", "node_features", "edge_features"}
    assert set(probe) == set(calibration)
    assert calibration["train_ts"].max() <= probe["train_ts"].min()

def test_cli_defaults_to_paper_mode(cli_runner):
    result = cli_runner("scripts/pretrain.py", "--print-config", "configs/smoke.yaml")
    assert result.returncode == 0
    assert '"time_encoding_mode": "paper_sincos"' in result.stdout
```

- [ ] **Step 2: Run tests and verify failure**

Run: `python -m pytest tests/test_proxy_boundary.py tests/test_cli_contracts.py -v`

Expected: FAIL.

- [ ] **Step 3: Port training behavior behind import-safe functions**

`run_pretraining(config, sources, seed, output_path)` constructs all objects inside the function, applies the exact global batch cap, records actual per-source batch counts, and saves checkpoint metadata. `score_target_train_proxy(...)` freezes the encoder, resets and trains only the target adapter/link head on calibration interactions, then computes AP/AUC on probe interactions. `run_transfer(..., mode)` supports `frozen`, `full`, and `scratch`; only downstream validation selects the checkpoint.

All four scripts contain only argument parsing plus one function call, for example:

```python
def main():
    args = parse_args()
    result = run_pretraining(ExperimentConfig.from_yaml(args.config), tuple(args.sources), args.seed, Path(args.output))
    print(json.dumps(result, sort_keys=True))
```

- [ ] **Step 4: Run proxy and CLI contract tests**

Run: `python -m pytest tests/test_proxy_boundary.py tests/test_cli_contracts.py -v`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/forward_pair/proxy.py src/tempofound/pretrain.py src/tempofound/transfer.py scripts tests/test_proxy_boundary.py tests/test_cli_contracts.py
git commit -m "feat: add paper-aligned training proxy and transfer CLIs"
```

### Task 7: Unified Resumable Experiment Pipelines

**Files:**
- Create: `src/forward_pair/pipeline.py`
- Create: `scripts/run_pipeline.py`
- Create: `experiments/run_k4_primary.sh`
- Create: `experiments/run_k6_scalability.sh`
- Create: `experiments/run_smoke.sh`
- Create: `experiments/controls/README.md`
- Create: `experiments/controls/run_random7.sh`
- Create: `experiments/controls/run_standard_greedy.sh`
- Create: `experiments/controls/run_exhaustive_diagnostic.sh`
- Create: `experiments/controls/run_graphmixer.sh`
- Test: `tests/test_pipeline_plan.py`
- Test: `tests/test_shell_syntax.py`

**Interfaces:**
- Consumes: config path, target list, seed list, processed-data root, output root, and device.
- Produces: a deterministic stage plan, resumable status records, validated artifacts, and control-specific outputs.

- [ ] **Step 1: Write failing pipeline-plan tests**

```python
def test_k4_plan_has_seven_candidate_jobs_before_retraining():
    plan = build_forward_pair_plan(config=k4_config(), target="mooc", seed=42)
    assert [job.kind for job in plan.jobs[:4]] == ["singleton"] * 4
    assert plan.dynamic_anchor_pair_count == 3
    assert plan.expected_candidate_count == 7

def test_default_pipeline_does_not_schedule_legacy_selector():
    plan = build_forward_pair_plan(config=k4_config(), target="mooc", seed=42)
    assert not any("proposed" in job.name or "leave_one" in job.name for job in plan.jobs)
```

- [ ] **Step 2: Run tests and verify failure**

Run: `python -m pytest tests/test_pipeline_plan.py tests/test_shell_syntax.py -v`

Expected: FAIL.

- [ ] **Step 3: Implement stage orchestration and thin launchers**

The pipeline runs singleton candidates, derives the anchor from validated singleton artifacts, runs anchor pairs, selects sources, retrains the selected set, runs all-source control, and evaluates transfer. Before skipping a successful stage, compare target, seed, source set, config digest, checkpoint time mode, and file existence. Shell launchers resolve the repository root and invoke:

```bash
python "${REPO_ROOT}/scripts/run_pipeline.py" \
  --config "${REPO_ROOT}/configs/k4_primary.yaml" \
  --processed-dir "${PROCESSED_DIR}" \
  --output-root "${OUTPUT_ROOT}" \
  --device "${DEVICE:-cuda:0}"
```

- [ ] **Step 4: Run plan and shell-syntax tests**

Run: `python -m pytest tests/test_pipeline_plan.py tests/test_shell_syntax.py -v && find experiments -name '*.sh' -print0 | xargs -0 -n1 bash -n`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/forward_pair/pipeline.py scripts/run_pipeline.py experiments tests/test_pipeline_plan.py tests/test_shell_syntax.py
git commit -m "feat: add unified K4 K6 and control pipelines"
```

### Task 8: Documentation, Paper Mapping, and Package Boundary

**Files:**
- Create: `README.md`
- Create: `README_CN.md`
- Create: `docs/PAPER_CODE_MAPPING.md`
- Create: `docs/SERVER_ACCEPTANCE_CN.md`
- Create: `scripts/check_package.py`
- Test: `tests/test_paper_mapping.py`
- Test: `tests/test_package_boundary.py`

**Interfaces:**
- Consumes: the completed repository.
- Produces: reproducible user instructions, manuscript-to-code traceability, and an archive eligibility check.

- [ ] **Step 1: Write failing documentation and boundary tests**

```python
def test_paper_mapping_names_all_core_components():
    text = Path("docs/PAPER_CODE_MAPPING.md").read_text()
    for name in ("Dataset-Specific Representation Adapters", "Causal Shared Temporal Encoder", "MTLP", "TNP", "CDC", "EDC", "NPP", "Forward-Pair", "2K-1"):
        assert name in text

def test_repository_contains_no_generated_artifacts():
    problems = find_forbidden_artifacts(Path("."))
    assert problems == []
```

- [ ] **Step 2: Run tests and verify failure**

Run: `python -m pytest tests/test_paper_mapping.py tests/test_package_boundary.py -v`

Expected: FAIL.

- [ ] **Step 3: Write concise English and Chinese instructions**

Document installation, data layout, smoke execution, K=4/K=6 commands, resume behavior, output schema, time-mode compatibility, limitations, and server acceptance. The mapping table links every manuscript method paragraph and experiment control to exact files/functions. `check_package.py` rejects generated directories and `.pth`, `.pt`, `.npy`, `.npz`, `.zip`, `.tar`, and `.gz` files outside test fixtures.

- [ ] **Step 4: Run documentation and package tests**

Run: `python -m pytest tests/test_paper_mapping.py tests/test_package_boundary.py -v && python scripts/check_package.py`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add README.md README_CN.md docs scripts/check_package.py tests/test_paper_mapping.py tests/test_package_boundary.py
git commit -m "docs: add reproducibility guide and paper code mapping"
```

### Task 9: Full Verification and Deliverable Archive

**Files:**
- Create: `VERIFICATION.md`
- Create: `MANIFEST.sha256`
- Create outside repository: `TempoFound_ForwardPair_Unified_v1.0.0.zip`

**Interfaces:**
- Consumes: all repository files and test commands.
- Produces: verified source archive and checksums.

- [ ] **Step 1: Run the complete CPU-verifiable suite**

Run: `python -m pytest -q`

Expected: all tests pass; CUDA/data-dependent tests are explicitly skipped with reasons.

- [ ] **Step 2: Run static and boundary checks**

Run: `python -m compileall -q src scripts tests && find experiments -name '*.sh' -print0 | xargs -0 -n1 bash -n && python scripts/check_package.py`

Expected: exit code 0 for every command.

- [ ] **Step 3: Run the synthetic smoke protocol**

Run: `bash experiments/run_smoke.sh`

Expected: exit code 0, seven K=4 candidate artifacts, one validated selection, one versioned checkpoint, and one frozen-transfer metrics row under a temporary output directory.

- [ ] **Step 4: Record evidence and create a deterministic manifest**

`VERIFICATION.md` records command, date, exit code, pass/skip counts, and environment limitations. Generate hashes with:

```bash
find . -type f -not -path './.git/*' -not -name MANIFEST.sha256 -print0 | sort -z | xargs -0 sha256sum > MANIFEST.sha256
```

- [ ] **Step 5: Build and inspect the archive**

Run: `zip -X -r ../TempoFound_ForwardPair_Unified_v1.0.0.zip . -x '.git/*' && unzip -t ../TempoFound_ForwardPair_Unified_v1.0.0.zip && unzip -l ../TempoFound_ForwardPair_Unified_v1.0.0.zip`

Expected: archive test passes and contains no forbidden artifacts.

- [ ] **Step 6: Commit verification evidence**

```bash
git add VERIFICATION.md MANIFEST.sha256
git commit -m "chore: record final verification evidence"
```
