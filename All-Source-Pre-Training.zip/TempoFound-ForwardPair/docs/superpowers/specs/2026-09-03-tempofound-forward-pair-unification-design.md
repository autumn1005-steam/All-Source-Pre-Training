# TempoFound + Forward-Pair Unified Repository Design

Date: 2026-09-03

## Goal

Create one clean, runnable repository that implements the manuscript's unified
pipeline: target-conditioned Forward-Pair source screening followed by
cross-dataset TempoFound pre-training and target transfer. The repository must
also reproduce legacy TempoFound checkpoints without maintaining a duplicate
codebase.

## Source Baselines

- TempoFound commit: `560ca56e8b4ecdb63ad9ba82d1c16cf7c5e9a723`
- Forward-Pair commit: `75357f19a0bb8f31aa8873b750d638181d0aec8a`
- Manuscript package: `Tempplus.zip`, manuscript dated 2026-09-03

The corrected Forward-Pair copy of the TempoFound engine is the behavioral
baseline because it already contains EDC naming and strict global batch-budget
allocation. The standalone TempoFound repository remains the provenance source
for the representation engine.

## Repository Shape

The deliverable contains one project rather than separate K=4 and K=6 trees.

```text
TempoFound-ForwardPair/
├── configs/                 # K=4, K=6, and smoke presets
├── docs/                    # architecture, paper mapping, server guide
├── experiments/             # primary and optional control entry points
├── src/
│   ├── tempofound/          # model, temporal encoder, data, training, transfer
│   └── forward_pair/        # proxy scoring and source selection
├── tests/                   # unit, contract, leakage, and smoke tests
├── pyproject.toml
├── README.md
└── README_CN.md
```

Generated data, checkpoints, logs, results, Python environments, and the
manuscript figures are excluded from the code archive.

## Model Architecture

TempoFound provides:

1. Dataset-specific two-layer node and edge adapters.
2. A learnable domain embedding added to adapted node features.
3. A shared causal TGAT-style encoder that retrieves only interactions with
   timestamps strictly earlier than the query timestamp.
4. Five pretext objectives: MTLP, TNP, CDC, EDC, and NPP.
5. Learned uncertainty weighting across the five objectives.
6. A strict global per-epoch update budget shared across active source domains.

The primary configuration matches the manuscript: shared dimension 128, time
dimension 64, two layers, two heads, ten historical neighbors, dropout 0.1,
25 pre-training epochs, batch size 512, and a global cap of 160 batches per
epoch.

## Dual Time-Encoding Modes

One harmonic encoder supports two modes:

- `paper_sincos` (default for new runs): returns normalized paired sine/cosine
  features as specified by the manuscript.
- `legacy_cos`: reproduces the original TempoFound cosine-only encoding.

Both modes retain a `basis_freq` vector of length `time_dim`, so legacy tensor
shapes remain loadable. `paper_sincos` uses the first half of those frequencies
to produce `time_dim / 2` cosine and `time_dim / 2` sine channels. It requires
an even time dimension and applies the manuscript normalization.

New checkpoints store `format_version` and `time_encoding_mode`. A checkpoint
without those fields is treated as `legacy_cos`. Explicitly forcing a mode that
conflicts with checkpoint metadata fails with a clear error instead of silently
changing model behavior.

## Forward-Pair Data Flow

For target T and K candidate sources:

1. Exclude T from the candidate source pool.
2. Train K singleton source models with identical architecture and global
   update budget.
3. Split only T's chronological training period into the first 80% for target
   adapter/link-head calibration and the final 20% for proxy scoring.
4. Select the strongest singleton anchor.
5. Train and score the K-1 pairs containing that anchor.
6. Keep the best pair only when its proxy AP improves over the anchor by at
   least 0.002; otherwise retain the singleton.
7. Re-train the selected source set from scratch under the common TempoFound
   pre-training protocol.
8. Run frozen-encoder target adaptation as the primary evaluation. Use target
   validation only for downstream checkpoint selection and report AP/AUC on the
   test interval.

The selector must assert that it evaluated exactly `2K-1` unique candidates.
Selection artifacts record scores, anchor, pair gain, margin, source set,
seed, target, time boundary, configuration digest, and source commits.

## Experiment Entry Points

- Primary: Forward-Pair versus all-source pre-training for the manuscript's
  K=4, targets, and five seeds.
- K=6: the same implementation with a larger source-pool configuration.
- Smoke: synthetic or tiny-budget end-to-end verification that cannot be
  mistaken for paper results.
- Optional controls: cardinality-matched random subsets, Random-7, standard
  greedy, exhaustive diagnostic, GraphMixer, full fine-tuning, scratch, node
  classification, margin/anchor/order ablations.

The default command runs only the primary Forward-Pair pipeline. Old
conflict-aware `proposed`/leave-one logic remains available only under an
explicit `experiments/legacy_controls/` namespace and is never selected by
default.

## Validation and Failure Behavior

Configuration validation fails before GPU work when:

- the target appears in the source pool;
- source names are duplicated or fewer than two sources are supplied;
- time or split parameters are invalid;
- required processed files are missing;
- requested candidate scores are missing, duplicated, non-finite, or have the
  wrong seed/target/configuration digest;
- the measured candidate set is not exactly the Forward-Pair singleton and
  anchor-pair set;
- a checkpoint's declared mode conflicts with the requested encoding mode;
- the global batch cap is exceeded.

Shell stages use resumable status plus artifact validation. A stale artifact
with mismatched metadata is rejected rather than skipped.

## Test Strategy

Tests cover:

- exact normalized `paper_sincos` and `legacy_cos` formulas;
- legacy checkpoint auto-detection and new checkpoint metadata;
- adapters and domain embeddings with heterogeneous feature dimensions;
- five loss terms and uncertainty-weighted aggregation;
- strict `< query_time` historical sampling;
- calibration/probe chronology and target validation/test exclusion;
- deterministic anchor and pair tie-breaking;
- margin boundary behavior and exactly `2K-1` candidates;
- exact global batch-budget allocation, including K=6;
- configuration loading and command construction;
- package-boundary, Python syntax, shell syntax, and CPU synthetic smoke tests.

GPU/data-dependent training is documented as a server acceptance step when the
delivery environment does not contain PyTorch or the processed datasets.

## Deliverable

The final ZIP contains the clean repository, provenance manifest, paper-to-code
mapping, test report, and server instructions. It excludes both original
repository archives and all generated experiment artifacts.
