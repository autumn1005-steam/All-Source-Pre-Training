# Manuscript-to-code mapping

| Manuscript component | Implementation |
|---|---|
| Dataset-Specific Representation Adapters | `tempofound.model.DatasetAdapter` |
| Causal Shared Temporal Encoder | `tempofound.model.SharedTemporalEncoder` and `tempofound.graph.NeighborFinder` |
| Normalized sine/cosine time encoding | `tempofound.layers.HarmonicTimeEncoder(mode="paper_sincos")` |
| Legacy cosine encoding | `tempofound.layers.HarmonicTimeEncoder(mode="legacy_cos")` |
| MTLP, TNP, CDC, EDC, NPP | `tempofound.model.TemporalGraphFoundationModel.pretrain_forward` |
| Adaptive uncertainty weighting | `tempofound.model.TemporalGraphFoundationModel.weighted_pretrain_loss` |
| Equal global update budget | `tempofound.budget.allocate_batch_budget` |
| Target-training-only proxy | `forward_pair.proxy.score_target_train_proxy` |
| Forward-Pair, exactly 2K-1 candidates | `forward_pair.selector.select_forward_pair` |
| Frozen/full/scratch transfer | `tempofound.transfer.run_transfer` |
| K=4 and K=6 protocols | `configs/k4_primary.yaml`, `configs/k6_scalability.yaml` |
| GraphMixer control | `configs/graphmixer_control.yaml` and `GraphMixerTemporalEncoder` |
| Random-7, exhaustive, greedy controls | `forward_pair.controls` and `experiments/controls/` |

The manuscript's node-classification paragraph is a supplementary limitation
statement rather than a primary result table. The unified default pipeline
therefore reproduces the paper's link-prediction protocol; it does not relabel
events or silently substitute a different node-classification protocol.

The JSON version of this mapping is tested by importing every referenced
symbol. This prevents the public documentation from drifting away from the
actual package structure.
