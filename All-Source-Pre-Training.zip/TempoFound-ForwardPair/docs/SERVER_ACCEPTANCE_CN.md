# AutoDL 服务器验收步骤

## 1. 解压与安装

```bash
unzip TempoFound_ForwardPair_Unified_v1.0.0.zip
cd TempoFound-ForwardPair
python -m pip install -e '.[test]'
```

建议使用论文环境 Python 3.12、PyTorch 2.12.1、CUDA 13.0 和 RTX 5090；
代码最低要求为 Python 3.10、PyTorch 2.0。

## 2. 静态与 CPU 验收

```bash
python -m pytest -q
python -m compileall -q src scripts tests
find experiments -name '*.sh' -print0 | xargs -0 -n1 bash -n
python scripts/check_package.py
bash experiments/run_smoke.sh
```

只有以上命令全部返回 0，才开始正式 GPU 实验。

## 3. 数据预检

```bash
for d in wikipedia reddit mooc uci enron lastfm socialevo; do
  for suffix in .csv .npy _node.npy; do
    test -s "/root/autodl-tmp/temp/processed/ml_${d}${suffix}" || echo "MISSING ml_${d}${suffix}"
  done
done
```

## 4. 正式运行

先运行 K=4；确认三个目标、五个种子的候选数均为 7 后，再运行 K=6。重新
执行同一命令即可断点续跑，但只有目标、种子、源集合和配置摘要全部一致的
产物才会跳过。

## 5. 结果检查

```bash
find /root/autodl-tmp/temp/server_runs -name summary.json -print
find /root/autodl-tmp/temp/server_runs -name selection.json -print
```

K=4 的 `candidate_count` 必须为 7，K=6 必须为 11。正式论文数值应来自
`transfer/*.json` 和 `summary.json`，不能使用 smoke 目录中的结果。
