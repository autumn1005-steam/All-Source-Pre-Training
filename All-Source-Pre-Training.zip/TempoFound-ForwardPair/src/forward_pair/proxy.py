"""Target-training-only calibration and proxy scoring."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import average_precision_score, roc_auc_score

from tempofound.checkpoint import load_foundation_checkpoint_payload
from tempofound.data import load_processed_dataset, split_target_train_period
from tempofound.model import (
    DatasetSpec,
    LinkPredictionHead,
    TemporalGraphFoundationModel,
)


PROXY_FIELDS = (
    "train_src",
    "train_dst",
    "train_ts",
    "neighbor_finder",
    "node_features",
    "edge_features",
)


def build_proxy_partitions(
    target_data: dict[str, Any], calibration_fraction: float = 0.8
) -> tuple[dict[str, Any], dict[str, Any]]:
    calibration, probe = split_target_train_period(
        target_data, calibration_fraction
    )

    def restricted(partition: dict[str, Any]) -> dict[str, Any]:
        return {field: partition[field] for field in PROXY_FIELDS}

    return restricted(calibration), restricted(probe)


def extend_model_for_target(
    model: TemporalGraphFoundationModel,
    target: str,
    target_data: dict[str, Any],
) -> TemporalGraphFoundationModel:
    if target in model.name_to_id:
        model.load_dataset_features(
            target, target_data["node_features"], target_data["edge_features"]
        )
        return model
    target_spec = DatasetSpec(
        name=target,
        raw_node_dim=int(target_data["node_features"].shape[1]),
        raw_edge_dim=int(target_data["edge_features"].shape[1]),
        n_nodes=int(target_data["node_features"].shape[0] - 1),
        n_edges=int(target_data["edge_features"].shape[0] - 1),
    )
    extended = TemporalGraphFoundationModel(
        (*model.dataset_specs, target_spec),
        shared_dim=model.shared_dim,
        time_dim=model.time_dim,
        num_layers=model.num_layers,
        num_heads=model.num_heads,
        dropout=model.dropout,
        num_neighbors=model.num_neighbors,
        time_encoding_mode=model.time_encoding_mode,
        backbone=model.backbone,
    ).to(model.device)
    old_state = model.state_dict()
    new_state = extended.state_dict()
    with torch.no_grad():
        for name, old_value in old_state.items():
            if name not in new_state:
                continue
            destination = new_state[name]
            if destination.shape == old_value.shape:
                destination.copy_(old_value)
            elif (
                destination.ndim == old_value.ndim
                and destination.ndim > 0
                and destination.shape[1:] == old_value.shape[1:]
                and destination.shape[0] >= old_value.shape[0]
            ):
                destination[: old_value.shape[0]].copy_(old_value)
    extended.load_state_dict(new_state)
    extended.load_dataset_features(
        target, target_data["node_features"], target_data["edge_features"]
    )
    return extended


def _link_logits(
    model: TemporalGraphFoundationModel,
    head: LinkPredictionHead,
    target: str,
    data: dict[str, Any],
    source: np.ndarray,
    destination: np.ndarray,
    timestamps: np.ndarray,
) -> torch.Tensor:
    source_embedding = model.encode_nodes(
        target, data["neighbor_finder"], source, timestamps
    )
    destination_embedding = model.encode_nodes(
        target, data["neighbor_finder"], destination, timestamps
    )
    return head(source_embedding, destination_embedding)


def score_target_train_proxy(
    model: TemporalGraphFoundationModel,
    *,
    target: str,
    target_data: dict[str, Any],
    seed: int,
    batch_size: int,
    calibration_steps: int,
    probe_batches: int,
    calibration_fraction: float,
    learning_rate: float = 1e-3,
) -> dict[str, Any]:
    if calibration_steps <= 0 or probe_batches <= 0 or batch_size <= 0:
        raise ValueError("proxy steps, batches, and batch_size must be positive")
    torch.manual_seed(seed + 11003)
    np.random.seed(seed + 11003)
    calibration, probe = build_proxy_partitions(
        target_data, calibration_fraction
    )
    model = extend_model_for_target(model, target, target_data)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    for parameter in model.adapters[target].parameters():
        parameter.requires_grad_(True)
    head = LinkPredictionHead(model.shared_dim, model.dropout).to(model.device)
    parameters = list(model.adapters[target].parameters()) + list(head.parameters())
    optimizer = torch.optim.Adam(parameters, lr=learning_rate)
    model.eval()
    model.adapters[target].train()
    head.train()
    rng = np.random.default_rng(seed + 12007)
    destination_pool = np.unique(calibration["train_dst"])
    calibration_losses: list[float] = []
    for _ in range(calibration_steps):
        indices = rng.choice(
            len(calibration["train_src"]),
            size=batch_size,
            replace=len(calibration["train_src"]) < batch_size,
        )
        source = calibration["train_src"][indices]
        destination = calibration["train_dst"][indices]
        timestamps = calibration["train_ts"][indices]
        negative = rng.choice(destination_pool, size=batch_size, replace=True)
        optimizer.zero_grad(set_to_none=True)
        positive_logits = _link_logits(
            model, head, target, calibration, source, destination, timestamps
        )
        negative_logits = _link_logits(
            model, head, target, calibration, source, negative, timestamps
        )
        loss = F.binary_cross_entropy_with_logits(
            positive_logits, torch.ones_like(positive_logits)
        ) + F.binary_cross_entropy_with_logits(
            negative_logits, torch.zeros_like(negative_logits)
        )
        loss.backward()
        optimizer.step()
        calibration_losses.append(float(loss.detach().cpu()))

    model.eval()
    head.eval()
    sample_count = batch_size * probe_batches
    indices = rng.choice(
        len(probe["train_src"]),
        size=sample_count,
        replace=len(probe["train_src"]) < sample_count,
    )
    labels: list[int] = []
    scores: list[float] = []
    with torch.no_grad():
        for batch_index in range(probe_batches):
            selected = indices[
                batch_index * batch_size : (batch_index + 1) * batch_size
            ]
            source = probe["train_src"][selected]
            destination = probe["train_dst"][selected]
            timestamps = probe["train_ts"][selected]
            negative = rng.choice(destination_pool, size=len(selected), replace=True)
            positive_logits = _link_logits(
                model, head, target, probe, source, destination, timestamps
            )
            negative_logits = _link_logits(
                model, head, target, probe, source, negative, timestamps
            )
            batch_scores = torch.sigmoid(
                torch.cat((positive_logits, negative_logits))
            ).cpu()
            labels.extend([1] * len(selected) + [0] * len(selected))
            scores.extend(batch_scores.tolist())
    return {
        "proxy_ap": float(average_precision_score(labels, scores)),
        "proxy_auc": float(roc_auc_score(labels, scores)),
        "calibration_final_loss": calibration_losses[-1],
        "calibration_steps": calibration_steps,
        "probe_batches": probe_batches,
        "information_boundary": "target_training_period_only",
    }


def score_checkpoint_proxy(
    checkpoint_path: str | Path,
    *,
    target: str,
    processed_dir: str | Path,
    seed: int,
    batch_size: int,
    calibration_steps: int,
    probe_batches: int,
    calibration_fraction: float,
    device: str = "cpu",
) -> dict[str, Any]:
    payload = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    model = load_foundation_checkpoint_payload(payload).to(torch.device(device))
    target_data = load_processed_dataset(target, processed_dir)
    return score_target_train_proxy(
        model,
        target=target,
        target_data=target_data,
        seed=seed,
        batch_size=batch_size,
        calibration_steps=calibration_steps,
        probe_batches=probe_batches,
        calibration_fraction=calibration_fraction,
    )
