"""Resumable end-to-end Forward-Pair experiment orchestration."""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from tempofound.config import ExperimentConfig
from tempofound.pretrain import run_pretraining
from tempofound.transfer import run_transfer

from .artifacts import write_selection_artifacts
from .proxy import score_checkpoint_proxy
from .selector import CandidateScore, select_forward_pair


@dataclass(frozen=True)
class PipelineJob:
    name: str
    kind: str
    sources: tuple[str, ...]


@dataclass(frozen=True)
class PipelinePlan:
    target: str
    seed: int
    singleton_jobs: tuple[PipelineJob, ...]
    dynamic_anchor_pair_count: int
    expected_candidate_count: int
    final_stages: tuple[str, ...]


def config_digest(config: ExperimentConfig) -> str:
    encoded = json.dumps(
        asdict(config), sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def build_forward_pair_plan(
    config: ExperimentConfig, *, target: str, seed: int
) -> PipelinePlan:
    sources = config.sources_for(target)
    if seed not in config.seeds_for(target):
        raise ValueError(f"seed {seed} is not configured for target {target}")
    singleton_jobs = tuple(
        PipelineJob(name=f"singleton_{source}", kind="singleton", sources=(source,))
        for source in sources
    )
    return PipelinePlan(
        target=target,
        seed=seed,
        singleton_jobs=singleton_jobs,
        dynamic_anchor_pair_count=len(sources) - 1,
        expected_candidate_count=2 * len(sources) - 1,
        final_stages=("selected_pretrain", "all_source_pretrain", "transfer"),
    )


def score_artifact_matches(
    path: str | Path,
    *,
    target: str,
    seed: int,
    sources: tuple[str, ...],
    digest: str,
) -> bool:
    artifact = Path(path)
    if not artifact.is_file():
        return False
    try:
        payload = json.loads(artifact.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    scores = (payload.get("proxy_ap"), payload.get("proxy_auc"))
    return (
        payload.get("target") == target
        and payload.get("seed") == seed
        and tuple(payload.get("sources", ())) == sources
        and payload.get("config_digest") == digest
        and all(
            isinstance(value, (int, float)) and math.isfinite(value)
            for value in scores
        )
    )


def result_artifact_matches(
    path: str | Path,
    *,
    target: str,
    seed: int,
    sources: tuple[str, ...],
    digest: str,
    mode: str,
) -> bool:
    artifact = Path(path)
    if not artifact.is_file():
        return False
    try:
        payload = json.loads(artifact.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    metrics = (payload.get("test_ap"), payload.get("test_auc"))
    return (
        payload.get("target") == target
        and payload.get("seed") == seed
        and tuple(payload.get("sources", ())) == sources
        and payload.get("config_digest") == digest
        and payload.get("mode") == mode
        and all(
            isinstance(value, (int, float)) and math.isfinite(value)
            for value in metrics
        )
    )


def _candidate_name(sources: tuple[str, ...]) -> str:
    return sources[0] if len(sources) == 1 else "pair_" + "_".join(sorted(sources))


def _read_candidate(path: Path) -> CandidateScore:
    payload = json.loads(path.read_text(encoding="utf-8"))
    return CandidateScore(
        config=payload["config"],
        sources=tuple(payload["sources"]),
        proxy_ap=float(payload["proxy_ap"]),
        proxy_auc=float(payload["proxy_auc"]),
        seed=int(payload["seed"]),
        target=payload["target"],
        config_digest=payload["config_digest"],
    )


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _checkpoint_manifest_matches(
    path: Path,
    *,
    checkpoint: Path,
    target: str,
    seed: int,
    sources: tuple[str, ...],
    digest: str,
) -> bool:
    if not path.is_file() or not checkpoint.is_file():
        return False
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    return payload == {
        "config_digest": digest,
        "seed": seed,
        "sources": list(sources),
        "target": target,
    }


def run_forward_pair_pipeline(
    config: ExperimentConfig,
    *,
    target: str,
    seed: int,
    processed_dir: str | Path,
    output_root: str | Path,
    device: str,
) -> dict[str, Any]:
    plan = build_forward_pair_plan(config, target=target, seed=seed)
    source_pool = config.sources_for(target)
    digest = config_digest(config)
    run_root = Path(output_root) / target / f"seed{seed}"
    candidate_root = run_root / "candidates"
    scores: list[CandidateScore] = []

    def evaluate_candidate(sources: tuple[str, ...]) -> CandidateScore:
        name = _candidate_name(sources)
        checkpoint = candidate_root / name / "pretrained.pth"
        score_path = candidate_root / name / "score.json"
        if not score_artifact_matches(
            score_path,
            target=target,
            seed=seed,
            sources=sources,
            digest=digest,
        ):
            run_pretraining(
                config,
                sources,
                seed,
                processed_dir,
                checkpoint,
                device,
            )
            metrics = score_checkpoint_proxy(
                checkpoint,
                target=target,
                processed_dir=processed_dir,
                seed=seed,
                batch_size=config.proxy_batch_size,
                calibration_steps=config.calibration_steps,
                probe_batches=config.proxy_batches,
                calibration_fraction=config.calibration_fraction,
                device=device,
            )
            _write_json(
                score_path,
                {
                    "config": name,
                    "sources": list(sources),
                    "proxy_ap": metrics["proxy_ap"],
                    "proxy_auc": metrics["proxy_auc"],
                    "seed": seed,
                    "target": target,
                    "config_digest": digest,
                    "information_boundary": metrics["information_boundary"],
                },
            )
        return _read_candidate(score_path)

    for job in plan.singleton_jobs:
        scores.append(evaluate_candidate(job.sources))
    singleton_scores = {score.sources[0]: score.proxy_ap for score in scores}
    anchor = min(
        source_pool, key=lambda source: (-singleton_scores[source], source)
    )
    for partner in source_pool:
        if partner != anchor:
            scores.append(evaluate_candidate((anchor, partner)))
    selection = select_forward_pair(scores, source_pool, config.margin)
    provenance = json.loads(
        (Path(__file__).resolve().parents[2] / "PROVENANCE.json").read_text(
            encoding="utf-8"
        )
    )
    selection_paths = write_selection_artifacts(
        run_root / "selection",
        scores,
        selection,
        source_commits={
            "TempoFound": provenance["tempofound_commit"],
            "Forward-Pair": provenance["forward_pair_commit"],
        },
    )

    def final_pretrain(label: str, sources: tuple[str, ...]) -> Path:
        checkpoint = run_root / "final" / label / "pretrained.pth"
        manifest = checkpoint.with_suffix(".manifest.json")
        if not _checkpoint_manifest_matches(
            manifest,
            checkpoint=checkpoint,
            target=target,
            seed=seed,
            sources=sources,
            digest=digest,
        ):
            run_pretraining(
                config, sources, seed, processed_dir, checkpoint, device
            )
            _write_json(
                manifest,
                {
                    "config_digest": digest,
                    "seed": seed,
                    "sources": list(sources),
                    "target": target,
                },
            )
        return checkpoint

    selected_checkpoint = final_pretrain("forward_pair", selection.selected_sources)
    all_checkpoint = final_pretrain("all_sources", source_pool)
    metrics: dict[str, Any] = {}
    for label, checkpoint in (
        ("forward_pair", selected_checkpoint),
        ("all_sources", all_checkpoint),
    ):
        result_path = run_root / "transfer" / f"{label}.json"
        result_sources = (
            selection.selected_sources if label == "forward_pair" else source_pool
        )
        if result_artifact_matches(
            result_path,
            target=target,
            seed=seed,
            sources=result_sources,
            digest=digest,
            mode="frozen",
        ):
            result = json.loads(result_path.read_text(encoding="utf-8"))
        else:
            result = run_transfer(
                config,
                checkpoint_path=checkpoint,
                target=target,
                seed=seed,
                processed_dir=processed_dir,
                mode="frozen",
                device=device,
            )
            result["config_digest"] = digest
            result["sources"] = list(result_sources)
            _write_json(result_path, result)
        metrics[label] = result
    summary = {
        "target": target,
        "seed": seed,
        "candidate_count": selection.candidate_count,
        "anchor_source": selection.anchor_source,
        "selected_sources": list(selection.selected_sources),
        "selection_json": str(selection_paths.selection_json),
        "forward_pair_test_ap": metrics["forward_pair"]["test_ap"],
        "all_sources_test_ap": metrics["all_sources"]["test_ap"],
        "ap_delta": metrics["forward_pair"]["test_ap"]
        - metrics["all_sources"]["test_ap"],
        "config_digest": digest,
    }
    _write_json(run_root / "summary.json", summary)
    return summary
