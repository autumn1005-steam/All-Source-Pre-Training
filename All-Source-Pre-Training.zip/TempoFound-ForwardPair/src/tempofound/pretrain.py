"""Compute-matched multi-source TempoFound pre-training."""

from __future__ import annotations

import math
import random
from pathlib import Path
from typing import Any

import numpy as np
import torch

from .budget import allocate_batch_budget
from .checkpoint import build_checkpoint
from .config import ExperimentConfig
from .data import load_processed_dataset
from .model import DatasetSpec, TemporalGraphFoundationModel


def _set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def _resolve_device(device: str) -> torch.device:
    resolved = torch.device(device)
    if resolved.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError(f"CUDA device requested but unavailable: {device}")
    return resolved


def _dataset_spec(name: str, data: dict[str, Any]) -> DatasetSpec:
    return DatasetSpec(
        name=name,
        raw_node_dim=int(data["node_features"].shape[1]),
        raw_edge_dim=int(data["edge_features"].shape[1]),
        n_nodes=int(data["node_features"].shape[0] - 1),
        n_edges=int(data["edge_features"].shape[0] - 1),
    )


def run_pretraining(
    config: ExperimentConfig,
    sources: tuple[str, ...],
    seed: int,
    processed_dir: str | Path,
    output_path: str | Path,
    device: str = "cpu",
) -> dict[str, Any]:
    if len(sources) != len(set(sources)) or not sources:
        raise ValueError("sources must contain unique dataset names")
    unknown = set(sources).difference(config.datasets)
    if unknown:
        raise ValueError(f"sources are not configured: {sorted(unknown)}")
    _set_seed(seed)
    torch_device = _resolve_device(device)
    data_by_source = {
        name: load_processed_dataset(name, processed_dir) for name in sources
    }
    model = TemporalGraphFoundationModel(
        tuple(_dataset_spec(name, data_by_source[name]) for name in sources),
        shared_dim=config.shared_dim,
        time_dim=config.time_dim,
        num_layers=config.num_layers,
        num_heads=config.num_heads,
        dropout=config.dropout,
        num_neighbors=config.num_neighbors,
        time_encoding_mode=config.time_encoding_mode,
        backbone=config.backbone,
    ).to(torch_device)
    for name, data in data_by_source.items():
        model.load_dataset_features(
            name, data["node_features"], data["edge_features"]
        )

    optimizer = torch.optim.AdamW(model.parameters(), lr=5e-4, weight_decay=1e-5)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=max(config.pretrain_epochs, 1)
    )
    epoch_batch_counts: list[int] = []
    source_batch_counts = {name: 0 for name in sources}
    epoch_mean_losses: list[float] = []
    rng = np.random.default_rng(seed)

    for epoch in range(config.pretrain_epochs):
        model.train()
        order = list(sources)
        random.Random(seed + epoch).shuffle(order)
        capacities = {
            name: math.ceil(len(data_by_source[name]["train_src"]) / config.batch_size)
            for name in order
        }
        budgets = allocate_batch_budget(
            capacities, config.total_batches_per_epoch
        )
        losses: list[float] = []
        for name in order:
            data = data_by_source[name]
            indices = rng.permutation(len(data["train_src"]))
            destination_pool = np.unique(data["train_dst"])
            for batch_index in range(budgets[name]):
                start = batch_index * config.batch_size
                stop = min(start + config.batch_size, len(indices))
                selected = indices[start:stop]
                if not len(selected):
                    continue
                source = data["train_src"][selected]
                destination = data["train_dst"][selected]
                timestamps = data["train_ts"][selected]
                negative = rng.choice(destination_pool, size=len(selected), replace=True)
                statistics = model.compute_neighborhood_stats(
                    data["neighbor_finder"], source, timestamps
                )
                batch = {
                    "src_idx": source,
                    "dst_idx": destination,
                    "neg_dst_idx": negative,
                    "cut_time": timestamps,
                    "ngh_stats": statistics,
                    "node_props": statistics,
                }
                optimizer.zero_grad(set_to_none=True)
                task_losses = model.pretrain_forward(
                    name, data["neighbor_finder"], batch
                )
                total = model.weighted_pretrain_loss(task_losses)
                total.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                optimizer.step()
                losses.append(float(total.detach().cpu()))
                source_batch_counts[name] += 1
        epoch_count = len(losses)
        if epoch_count > config.total_batches_per_epoch:
            raise RuntimeError("global batch budget was exceeded")
        epoch_batch_counts.append(epoch_count)
        epoch_mean_losses.append(float(np.mean(losses)) if losses else float("nan"))
        scheduler.step()

    summary = {
        "sources": list(sources),
        "seed": seed,
        "time_encoding_mode": config.time_encoding_mode,
        "epoch_batch_counts": epoch_batch_counts,
        "source_batch_counts": source_batch_counts,
        "epoch_mean_losses": epoch_mean_losses,
        "global_batch_cap": config.total_batches_per_epoch,
    }
    payload = build_checkpoint(
        model,
        time_encoding_mode=config.time_encoding_mode,
        model_config=model.model_config(),
        metadata={"pretraining": summary, "experiment": config.name},
    )
    destination = Path(output_path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    torch.save(payload, destination)
    return summary
