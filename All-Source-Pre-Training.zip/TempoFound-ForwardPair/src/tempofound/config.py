"""Validated experiment configuration shared by K=4 and K=6 protocols."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping

import yaml


def _tuple_map(values: Mapping[str, Any] | None) -> dict[str, tuple[Any, ...]]:
    return {str(key): tuple(value) for key, value in (values or {}).items()}


@dataclass(frozen=True)
class ExperimentConfig:
    name: str
    datasets: tuple[str, ...]
    targets: tuple[str, ...]
    seeds: tuple[int, ...] = (0, 1, 2, 3, 42)
    source_overrides: Mapping[str, tuple[str, ...]] = field(default_factory=dict)
    seed_overrides: Mapping[str, tuple[int, ...]] = field(default_factory=dict)
    shared_dim: int = 128
    time_dim: int = 64
    num_layers: int = 2
    num_heads: int = 2
    num_neighbors: int = 10
    dropout: float = 0.1
    pretrain_epochs: int = 25
    transfer_epochs: int = 20
    batch_size: int = 512
    total_batches_per_epoch: int = 160
    calibration_fraction: float = 0.8
    calibration_steps: int = 100
    proxy_batch_size: int = 256
    proxy_batches: int = 12
    margin: float = 0.002
    time_encoding_mode: str = "paper_sincos"
    backbone: str = "tgat"

    def __post_init__(self) -> None:
        if len(self.datasets) != len(set(self.datasets)):
            raise ValueError("datasets must be unique")
        if len(self.targets) != len(set(self.targets)):
            raise ValueError("targets must be unique")
        unknown_targets = set(self.targets).difference(self.datasets)
        if unknown_targets:
            raise ValueError(f"targets missing from datasets: {sorted(unknown_targets)}")
        if self.time_encoding_mode not in {"paper_sincos", "legacy_cos"}:
            raise ValueError("time_encoding_mode must be paper_sincos or legacy_cos")
        if self.backbone not in {"tgat", "graphmixer"}:
            raise ValueError("backbone must be tgat or graphmixer")
        if self.time_encoding_mode == "paper_sincos" and self.time_dim % 2:
            raise ValueError("paper_sincos requires an even time_dim")
        if not 0.0 < self.calibration_fraction < 1.0:
            raise ValueError("calibration_fraction must be between zero and one")
        if self.margin < 0.0:
            raise ValueError("margin must be non-negative")
        if self.total_batches_per_epoch <= 0:
            raise ValueError("total_batches_per_epoch must be positive")
        for target in self.targets:
            sources = self.sources_for(target)
            if target in sources:
                raise ValueError("target cannot appear in source pool")
            if len(sources) < 2 or len(sources) != len(set(sources)):
                raise ValueError("each target requires at least two unique sources")
            unknown_sources = set(sources).difference(self.datasets)
            if unknown_sources:
                raise ValueError(
                    f"source pool contains unknown datasets: {sorted(unknown_sources)}"
                )

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> "ExperimentConfig":
        model = dict(raw.get("model", {}))
        training = dict(raw.get("training", {}))
        proxy = dict(raw.get("proxy", {}))
        merged = {
            "name": raw["name"],
            "datasets": tuple(raw["datasets"]),
            "targets": tuple(raw["targets"]),
            "seeds": tuple(int(seed) for seed in raw.get("seeds", (0, 1, 2, 3, 42))),
            "source_overrides": _tuple_map(raw.get("source_overrides")),
            "seed_overrides": {
                key: tuple(int(seed) for seed in value)
                for key, value in _tuple_map(raw.get("seed_overrides")).items()
            },
            **model,
            **training,
            **proxy,
        }
        if "time_encoding_mode" in raw:
            merged["time_encoding_mode"] = raw["time_encoding_mode"]
        return cls(**merged)

    @classmethod
    def from_yaml(cls, path: str | Path) -> "ExperimentConfig":
        with Path(path).open("r", encoding="utf-8") as handle:
            raw = yaml.safe_load(handle)
        if not isinstance(raw, dict):
            raise ValueError("configuration root must be a mapping")
        return cls.from_mapping(raw)

    def sources_for(self, target: str) -> tuple[str, ...]:
        if target not in self.targets:
            raise ValueError(f"target is not configured: {target}")
        override = self.source_overrides.get(target)
        if override is not None:
            return tuple(override)
        return tuple(dataset for dataset in self.datasets if dataset != target)

    def seeds_for(self, target: str) -> tuple[int, ...]:
        if target not in self.targets:
            raise ValueError(f"target is not configured: {target}")
        return tuple(self.seed_overrides.get(target, self.seeds))
