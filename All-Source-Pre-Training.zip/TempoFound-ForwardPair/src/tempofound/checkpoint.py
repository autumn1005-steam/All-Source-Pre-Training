"""Versioned checkpoint helpers and time-mode compatibility."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from torch import nn


FORMAT_VERSION = 2
SUPPORTED_TIME_MODES = frozenset({"paper_sincos", "legacy_cos"})


def resolve_checkpoint_time_mode(
    payload: Mapping[str, Any], requested: str | None = None
) -> str:
    """Resolve a checkpoint's behavior without silently changing old models."""
    stored = payload.get("time_encoding_mode")
    if stored is None:
        stored = "legacy_cos"
    if stored not in SUPPORTED_TIME_MODES:
        raise ValueError(f"checkpoint has unsupported time encoding mode: {stored}")
    if requested is not None and requested not in SUPPORTED_TIME_MODES:
        raise ValueError(f"unsupported requested time encoding mode: {requested}")
    if requested is not None and requested != stored:
        raise ValueError(
            f"requested time encoding mode {requested!r} conflicts with "
            f"checkpoint mode {stored!r}"
        )
    return str(stored)


def build_checkpoint(
    model: nn.Module,
    *,
    time_encoding_mode: str,
    model_config: Mapping[str, Any],
    metadata: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    if time_encoding_mode not in SUPPORTED_TIME_MODES:
        raise ValueError(f"unsupported time encoding mode: {time_encoding_mode}")
    return {
        "format_version": FORMAT_VERSION,
        "time_encoding_mode": time_encoding_mode,
        "model_config": dict(model_config),
        "model_state_dict": model.state_dict(),
        "metadata": dict(metadata or {}),
    }


def load_foundation_checkpoint_payload(
    payload: Mapping[str, Any],
    *,
    requested_time_encoding_mode: str | None = None,
) -> nn.Module:
    """Construct a foundation model from new or released legacy metadata."""
    from .model import DatasetSpec, TemporalGraphFoundationModel

    mode = resolve_checkpoint_time_mode(payload, requested_time_encoding_mode)
    if "model_config" in payload:
        config = dict(payload["model_config"])
        raw_specs = config.pop("dataset_specs")
        config["time_encoding_mode"] = mode
        specs = tuple(DatasetSpec.from_mapping(value) for value in raw_specs)
    else:
        specs = tuple(
            DatasetSpec.from_mapping(value) for value in payload["dataset_configs"]
        )
        config = {
            "shared_dim": int(payload["shared_dim"]),
            "time_dim": int(payload["time_dim"]),
            "num_layers": int(payload["num_layers"]),
            "num_heads": int(payload.get("num_heads", payload.get("n_head", 2))),
            "dropout": float(payload.get("dropout", 0.1)),
            "num_neighbors": int(payload["num_neighbors"]),
            "time_encoding_mode": mode,
        }
    model = TemporalGraphFoundationModel(specs, **config)
    state = payload["model_state_dict"]
    current_state = model.state_dict()
    if (
        set(state) == set(current_state)
        and "task_log_vars" in state
        and tuple(state["task_log_vars"].shape) == (4,)
        and tuple(current_state["task_log_vars"].shape) == (5,)
        and all(
            tuple(state[name].shape) == tuple(value.shape)
            for name, value in current_state.items()
            if name != "task_log_vars"
        )
    ):
        migrated_state = dict(state)
        migrated_task_weights = current_state["task_log_vars"].clone()
        migrated_task_weights[:4].copy_(state["task_log_vars"])
        migrated_state["task_log_vars"] = migrated_task_weights
        state = migrated_state
    try:
        model.load_state_dict(state, strict=True)
    except RuntimeError as error:
        raise ValueError(
            "checkpoint parameters do not match the unified TempoFound architecture"
        ) from error
    return model
