"""Frozen-encoder, full-fine-tuning, and scratch target transfer."""

from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import average_precision_score, roc_auc_score

from forward_pair.proxy import extend_model_for_target

from .checkpoint import load_foundation_checkpoint_payload
from .config import ExperimentConfig
from .data import load_processed_dataset
from .model import DatasetSpec, LinkPredictionHead, TemporalGraphFoundationModel


def _target_spec(name: str, data: dict[str, Any]) -> DatasetSpec:
    return DatasetSpec(
        name=name,
        raw_node_dim=int(data["node_features"].shape[1]),
        raw_edge_dim=int(data["edge_features"].shape[1]),
        n_nodes=int(data["node_features"].shape[0] - 1),
        n_edges=int(data["edge_features"].shape[0] - 1),
    )


def _logits(
    model: TemporalGraphFoundationModel,
    head: LinkPredictionHead,
    target: str,
    data: dict[str, Any],
    source: np.ndarray,
    destination: np.ndarray,
    timestamps: np.ndarray,
) -> torch.Tensor:
    source_embedding = model.encode_nodes(
        target, data["neighbor_finder"], source, timestamps
    )
    destination_embedding = model.encode_nodes(
        target, data["neighbor_finder"], destination, timestamps
    )
    return head(source_embedding, destination_embedding)


@torch.no_grad()
def _evaluate(
    model: TemporalGraphFoundationModel,
    head: LinkPredictionHead,
    target: str,
    data: dict[str, Any],
    split: str,
    destination_pool: np.ndarray,
    seed: int,
) -> tuple[float, float]:
    model.eval()
    head.eval()
    source = data[f"{split}_src"]
    destination = data[f"{split}_dst"]
    timestamps = data[f"{split}_ts"]
    rng = np.random.default_rng(seed)
    negative = rng.choice(destination_pool, size=len(source), replace=True)
    positive_logits = _logits(
        model, head, target, data, source, destination, timestamps
    )
    negative_logits = _logits(
        model, head, target, data, source, negative, timestamps
    )
    labels = np.concatenate((np.ones(len(source)), np.zeros(len(source))))
    scores = torch.sigmoid(torch.cat((positive_logits, negative_logits))).cpu().numpy()
    return (
        float(average_precision_score(labels, scores)),
        float(roc_auc_score(labels, scores)),
    )


def run_transfer(
    config: ExperimentConfig,
    *,
    checkpoint_path: str | Path | None,
    target: str,
    seed: int,
    processed_dir: str | Path,
    mode: str = "frozen",
    device: str = "cpu",
) -> dict[str, Any]:
    if mode not in {"frozen", "full", "scratch"}:
        raise ValueError("mode must be frozen, full, or scratch")
    torch.manual_seed(seed)
    np.random.seed(seed)
    target_data = load_processed_dataset(target, processed_dir)
    torch_device = torch.device(device)
    if mode == "scratch":
        model = TemporalGraphFoundationModel(
            (_target_spec(target, target_data),),
            shared_dim=config.shared_dim,
            time_dim=config.time_dim,
            num_layers=config.num_layers,
            num_heads=config.num_heads,
            dropout=config.dropout,
            num_neighbors=config.num_neighbors,
            time_encoding_mode=config.time_encoding_mode,
            backbone=config.backbone,
        ).to(torch_device)
        model.load_dataset_features(
            target, target_data["node_features"], target_data["edge_features"]
        )
    else:
        if checkpoint_path is None:
            raise ValueError("checkpoint_path is required for frozen or full transfer")
        payload = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
        model = load_foundation_checkpoint_payload(payload).to(torch_device)
        model = extend_model_for_target(model, target, target_data)
    head = LinkPredictionHead(model.shared_dim, config.dropout).to(torch_device)

    for parameter in model.parameters():
        parameter.requires_grad_(False)
    if mode == "frozen":
        for parameter in model.adapters[target].parameters():
            parameter.requires_grad_(True)
    else:
        for parameter in model.encoder.parameters():
            parameter.requires_grad_(True)
        for adapter in model.adapters.values():
            for parameter in adapter.parameters():
                parameter.requires_grad_(True)
    trainable = [parameter for parameter in model.parameters() if parameter.requires_grad]
    trainable.extend(head.parameters())
    optimizer = torch.optim.Adam(trainable, lr=1e-3)
    destination_pool = np.unique(target_data["train_dst"])
    rng = np.random.default_rng(seed + 20011)
    best_validation_ap = -1.0
    best_model_state: dict[str, torch.Tensor] | None = None
    best_head_state: dict[str, torch.Tensor] | None = None

    for epoch in range(config.transfer_epochs):
        if mode == "frozen":
            model.eval()
            model.adapters[target].train()
        else:
            model.train()
        head.train()
        indices = rng.permutation(len(target_data["train_src"]))
        for start in range(0, len(indices), config.batch_size):
            selected = indices[start : start + config.batch_size]
            source = target_data["train_src"][selected]
            destination = target_data["train_dst"][selected]
            timestamps = target_data["train_ts"][selected]
            negative = rng.choice(destination_pool, size=len(selected), replace=True)
            optimizer.zero_grad(set_to_none=True)
            positive_logits = _logits(
                model, head, target, target_data, source, destination, timestamps
            )
            negative_logits = _logits(
                model, head, target, target_data, source, negative, timestamps
            )
            loss = F.binary_cross_entropy_with_logits(
                positive_logits, torch.ones_like(positive_logits)
            ) + F.binary_cross_entropy_with_logits(
                negative_logits, torch.zeros_like(negative_logits)
            )
            loss.backward()
            torch.nn.utils.clip_grad_norm_(trainable, max_norm=1.0)
            optimizer.step()
        validation_ap, _ = _evaluate(
            model,
            head,
            target,
            target_data,
            "val",
            destination_pool,
            seed + 30011 + epoch,
        )
        if validation_ap > best_validation_ap:
            best_validation_ap = validation_ap
            best_model_state = deepcopy(model.state_dict())
            best_head_state = deepcopy(head.state_dict())

    if best_model_state is None or best_head_state is None:
        raise RuntimeError("transfer produced no validation checkpoint")
    model.load_state_dict(best_model_state)
    head.load_state_dict(best_head_state)
    test_ap, test_auc = _evaluate(
        model,
        head,
        target,
        target_data,
        "test",
        destination_pool,
        seed + 40009,
    )
    return {
        "target": target,
        "seed": seed,
        "mode": mode,
        "validation_ap": best_validation_ap,
        "test_ap": test_ap,
        "test_auc": test_auc,
        "checkpoint_selection_scope": "target_validation_only_after_source_selection",
    }
